from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
def index():
    data = {
        "nombre": "Dalbiery",
        "apellidos": ["Rodriguez", "Rodriguez"],
        "asignaturas": [
            "INF-422-02", "ECO-585-02", "INF-451-04", "INF-452-53", 
            "INF-560-01", "INF-902-01", "MAT-322-01"
        ],
        "hobbies": [
            "Jugar videojuegos", "Hacer ciclismo", 
            "Estudiar redes informáticas", "Escuchar música"
        ]
    }
    return render_template("index.html", data=data)

if __name__ == '__main__':
    app.run(debug=True)
